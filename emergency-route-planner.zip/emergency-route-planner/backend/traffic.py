"""
traffic.py - predicts traffic and turns it into travel times (the edge weights).

Congestion on a road is predicted from:
  * time of day      - morning rush around 09:30, evening rush around 18:30
  * weekday/weekend  - weekends have one smaller midday peak
  * road type        - main roads and bridges get busier than local streets
  * centrality       - roads near the city centre are busier
  * hotspot factor   - fixed per road (markets, schools, offices...)

Travel time for an ambulance on a road:
    time = length / ambulance_speed  +  signal wait at the next junction
    ambulance_speed = speed_limit / (1 + 0.55 * congestion)
(ambulances use sirens, so they feel only part of the congestion)
"""
import math

from .city import MAX_SPEED

ROAD_TYPE_FACTOR = {"local": 0.45, "arterial": 1.1, "bridge": 1.6}
SIREN_FACTOR = 0.55            # share of the congestion an ambulance still feels
GREEN_CORRIDOR_WAIT = 2.0      # seconds lost at a signal that was switched green for us


def rush_factor(hour, weekend):
    """How busy the city is overall at this hour (about 0.15 at night, about 1.0 at rush hour)."""
    if weekend:
        return 0.15 + 0.55 * math.exp(-((hour - 13) / 3.5) ** 2)
    return (0.15
            + 0.85 * math.exp(-((hour - 9.5) / 1.4) ** 2)
            + 0.95 * math.exp(-((hour - 18.5) / 1.8) ** 2))


class TrafficModel:
    def __init__(self, city):
        self.city = city
        self.closed = set()            # road ids that are blocked (accidents etc.)
        self.green_corridor = True     # signal pre-emption on/off
        self.travel_time = [0.0] * len(city.roads)
        self.flow_ratio = [1.0] * len(city.roads)    # 1 = free flow, smaller = slower
        self.signal_wait = [0.0] * len(city.junctions)
        self.update(9, False)

    def update(self, hour, weekend):
        """Recalculate every road for a new time of day."""
        self.hour, self.weekend = hour, weekend
        rush = rush_factor(hour, weekend)
        for road in self.city.roads:
            congestion = rush * ROAD_TYPE_FACTOR[road.kind] * (0.35 + road.centrality) * road.hotspot
            self.flow_ratio[road.id] = 1 / (1 + congestion)
            speed = (road.speed_limit / 3.6) / (1 + SIREN_FACTOR * congestion)   # m/s
            self.travel_time[road.id] = road.length / speed
        for j in self.city.junctions:
            self.signal_wait[j.id] = 5 + 30 * min(1.2, rush) * j.signal_weight if j.has_signal else 0.0

    def level(self, road_id):
        """0 = clear, 1 = slow, 2 = jammed (used for the map colours)."""
        r = self.flow_ratio[road_id]
        return 0 if r > 0.72 else 1 if r > 0.42 else 2

    def cost(self, u, v, road_id, corridor=None):
        """Seconds to drive from junction u to junction v along road_id."""
        if road_id in self.closed:
            return math.inf
        if corridor is None:
            corridor = self.green_corridor
        wait = 0.0
        if self.city.junctions[v].has_signal:
            wait = GREEN_CORRIDOR_WAIT if corridor else self.signal_wait[v]
        return self.travel_time[road_id] + wait

    def heuristic(self, a, b):
        """A* estimate: straight-line distance at top speed. It never overestimates."""
        return self.city.straight_line(a, b) / MAX_SPEED

    def path_time(self, path, corridor=None):
        if not path:
            return math.inf
        total = 0.0
        for u, v in zip(path, path[1:]):
            total += self.cost(u, v, self.city.road_between(u, v), corridor)
        return total

    def path_length(self, path):
        return sum(self.city.roads[self.city.road_between(u, v)].length for u, v in zip(path, path[1:]))
