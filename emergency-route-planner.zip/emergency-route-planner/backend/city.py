"""
city.py - builds the demo city road network.

The city is stored as a graph:
  * junctions (nodes) - an 18 x 12 grid, shifted a little so it looks less perfect
  * roads (edges)     - connect neighbouring junctions
A river runs across the middle and can only be crossed at 4 bridges,
so route choice actually matters.
"""
import math
from dataclasses import dataclass

COLS, ROWS = 18, 12
SPACING = 260            # metres between neighbouring junctions
RIVER_GAP = 140          # extra space between row 5 and row 6 for the river
ARTERIAL_ROWS = [1, 4, 7, 10]
ARTERIAL_COLS = [1, 5, 9, 13, 16]
BRIDGE_COLS = [1, 5, 9, 13]
SPEED_LIMIT = {"local": 30, "bridge": 40, "arterial": 50}   # km/h
MAX_SPEED = 50 / 3.6     # m/s, the fastest any road allows (used by the A* heuristic)

HOSPITALS = [
    ("Northgate Hospital", 4, 1),
    ("Civic General", 14, 2),
    ("Riverside Care", 10, 8),
    ("Westend Medical", 1, 9),
]
AMBULANCE_BASES = [(2, 3), (9, 3), (16, 4), (6, 8), (14, 10)]


class SeededRandom:
    """Small repeatable random number generator, so the city is the same on every run."""

    def __init__(self, seed):
        self.seed = seed

    def random(self):
        self.seed = self.seed * 16807 % 2147483647
        return self.seed / 2147483647


@dataclass
class Junction:
    id: int
    col: int
    row: int
    x: float
    y: float
    has_signal: bool = False
    signal_weight: float = 0.0   # 1.0 = big crossing of two main roads, 0.6 = smaller


@dataclass
class Road:
    id: int
    a: int
    b: int
    kind: str            # "local", "arterial" or "bridge"
    length: float        # metres
    speed_limit: float   # km/h
    hotspot: float       # how busy this road is compared with similar roads (markets, schools...)
    centrality: float = 0.0   # 1 = city centre, 0 = edge of the city
    removed: bool = False     # some local streets are removed to make the grid irregular


class City:
    def __init__(self, seed=56060):
        rnd = SeededRandom(seed)
        self.junctions = []
        self.roads = []

        # 1. junctions
        for r in range(ROWS):
            for c in range(COLS):
                x = c * SPACING + (rnd.random() - 0.5) * 90
                y = r * SPACING + (RIVER_GAP if r > 5 else 0) + (rnd.random() - 0.5) * 90
                self.junctions.append(Junction(len(self.junctions), c, r, x, y))
        self.river_y = 5.5 * SPACING + RIVER_GAP / 2

        # 2. grid roads (the river between row 5 and 6 only has bridges)
        for r in range(ROWS):
            for c in range(COLS):
                if c < COLS - 1:
                    kind = "arterial" if r in ARTERIAL_ROWS else "local"
                    self._add_road(self.node_id(c, r), self.node_id(c + 1, r), kind, rnd)
                if r < ROWS - 1:
                    if r == 5:
                        if c in BRIDGE_COLS:
                            self._add_road(self.node_id(c, r), self.node_id(c, r + 1), "bridge", rnd)
                    else:
                        kind = "arterial" if c in ARTERIAL_COLS else "local"
                        self._add_road(self.node_id(c, r), self.node_id(c, r + 1), kind, rnd)

        # 3. two diagonal avenues
        for k in range(5):
            self._add_road(self.node_id(3 + k, 11 - k), self.node_id(4 + k, 10 - k), "arterial", rnd)
        for k in range(4):
            self._add_road(self.node_id(10 + k, 4 - k), self.node_id(11 + k, 3 - k), "arterial", rnd)

        # 4. remove about 13% of local streets, but never disconnect the city
        local = [road.id for road in self.roads if road.kind == "local"]
        for i in range(len(local) - 1, 0, -1):
            j = int(rnd.random() * (i + 1))
            local[i], local[j] = local[j], local[i]
        for road_id in local[:int(len(local) * 0.13 + 0.5)]:
            self.roads[road_id].removed = True
            if not self._is_connected():
                self.roads[road_id].removed = False

        # 5. adjacency list: for each junction, the (neighbour, road_id) pairs
        self.adjacency = [[] for _ in self.junctions]
        for road in self.roads:
            if not road.removed:
                self.adjacency[road.a].append((road.b, road.id))
                self.adjacency[road.b].append((road.a, road.id))

        # 6. how central each road is (centre roads get more traffic)
        xs = [j.x for j in self.junctions]
        ys = [j.y for j in self.junctions]
        self.bounds = (min(xs), min(ys), max(xs), max(ys))
        cx, cy = (self.bounds[0] + self.bounds[2]) / 2, (self.bounds[1] + self.bounds[3]) / 2
        far = math.hypot(self.bounds[2] - cx, self.bounds[3] - cy)
        for road in self.roads:
            a, b = self.junctions[road.a], self.junctions[road.b]
            mid_x, mid_y = (a.x + b.x) / 2, (a.y + b.y) / 2
            road.centrality = 1 - math.hypot(mid_x - cx, mid_y - cy) / far

        # 7. traffic signals at busy junctions
        for j in self.junctions:
            links = self.adjacency[j.id]
            main_roads = sum(1 for _, rid in links if self.roads[rid].kind != "local")
            if len(links) >= 3 and main_roads >= 1 and rnd.random() < 0.8:
                j.has_signal = True
                j.signal_weight = 1.0 if main_roads >= 2 else 0.6

        self.hospitals = [{"name": name, "node": self.node_id(c, r)} for name, c, r in HOSPITALS]
        self.bases = [self.node_id(c, r) for c, r in AMBULANCE_BASES]

    # ---------- building helpers ----------
    def _add_road(self, a, b, kind, rnd):
        ja, jb = self.junctions[a], self.junctions[b]
        hotspot = 1.1 + rnd.random() * 0.5 if kind == "bridge" else 0.7 + rnd.random() * 0.8
        self.roads.append(Road(len(self.roads), a, b, kind, math.hypot(ja.x - jb.x, ja.y - jb.y),
                               SPEED_LIMIT[kind], hotspot))

    def _is_connected(self):
        neighbours = [[] for _ in self.junctions]
        for road in self.roads:
            if not road.removed:
                neighbours[road.a].append(road.b)
                neighbours[road.b].append(road.a)
        seen = {0}
        stack = [0]
        while stack:
            u = stack.pop()
            for v in neighbours[u]:
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        return len(seen) == len(self.junctions)

    # ---------- lookups ----------
    @staticmethod
    def node_id(col, row):
        return row * COLS + col

    def road_between(self, u, v):
        for w, road_id in self.adjacency[u]:
            if w == v:
                return road_id
        return None

    def straight_line(self, a, b):
        ja, jb = self.junctions[a], self.junctions[b]
        return math.hypot(ja.x - jb.x, ja.y - jb.y)

    def nearest_junction(self, x, y):
        return min(self.junctions, key=lambda j: (j.x - x) ** 2 + (j.y - y) ** 2).id

    def to_dict(self):
        """Static map data for the frontend (sent once)."""
        return {
            "junctions": [{"id": j.id, "x": round(j.x, 1), "y": round(j.y, 1), "signal": j.has_signal}
                          for j in self.junctions],
            "roads": [{"id": r.id, "a": r.a, "b": r.b, "kind": r.kind}
                      for r in self.roads if not r.removed],
            "hospitals": [{"name": h["name"], "x": round(self.junctions[h["node"]].x, 1),
                           "y": round(self.junctions[h["node"]].y, 1)} for h in self.hospitals],
            "bounds": [round(v, 1) for v in self.bounds],
            "river_y": self.river_y,
        }
