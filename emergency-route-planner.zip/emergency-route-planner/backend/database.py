"""
database.py - saves every emergency call and every log message in SQLite.

SQLite is built into Python, so there is nothing extra to install.
The file is created at data/dispatch.db the first time the server starts,
and the history is kept when the server restarts.
"""
import os
import sqlite3
from datetime import datetime

DB_PATH = os.environ.get("DISPATCH_DB") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "dispatch.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    reported_at     TEXT NOT NULL,
    junction        INTEGER NOT NULL,
    ambulance       TEXT,
    hospital        TEXT,
    status          TEXT NOT NULL,      -- dispatched / on_scene / completed
    traffic_hour    INTEGER,
    algorithm       TEXT,
    eta_scene_s     REAL,               -- predicted time to reach the patient
    time_to_scene_s REAL,               -- actual time to reach the patient
    total_time_s    REAL                -- call to hospital arrival
);
CREATE TABLE IF NOT EXISTS events (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    logged_at TEXT NOT NULL,
    sim_time  REAL,
    message   TEXT NOT NULL
);
"""

UPDATABLE = {"status", "eta_scene_s", "time_to_scene_s", "total_time_s"}


def _connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _run(sql, params=(), fetch=False):
    conn = _connect()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        if fetch:
            return [dict(row) for row in cur.fetchall()]
        return cur.lastrowid
    finally:
        conn.close()


def _now():
    return datetime.now().isoformat(timespec="seconds")


def init_db():
    conn = _connect()
    try:
        conn.executescript(SCHEMA)
    finally:
        conn.close()


def add_incident(junction, ambulance, hospital, hour, algorithm):
    return _run("INSERT INTO incidents (reported_at, junction, ambulance, hospital, status, traffic_hour, algorithm) "
                "VALUES (?, ?, ?, ?, 'dispatched', ?, ?)",
                (_now(), junction, ambulance, hospital, hour, algorithm))


def update_incident(incident_id, **fields):
    fields = {k: v for k, v in fields.items() if k in UPDATABLE}
    if not fields:
        return
    sets = ", ".join(f"{k} = ?" for k in fields)
    _run(f"UPDATE incidents SET {sets} WHERE id = ?", (*fields.values(), incident_id))


def add_event(sim_time, message):
    _run("INSERT INTO events (logged_at, sim_time, message) VALUES (?, ?, ?)", (_now(), sim_time, message))


def recent_incidents(limit=15):
    return _run("SELECT * FROM incidents ORDER BY id DESC LIMIT ?", (limit,), fetch=True)


def summary():
    row = _run("SELECT COUNT(*) AS calls, "
               "SUM(status = 'completed') AS completed, "
               "AVG(time_to_scene_s) AS avg_to_scene, "
               "AVG(total_time_s) AS avg_total FROM incidents", fetch=True)[0]
    row["calls"] = row["calls"] or 0
    row["completed"] = row["completed"] or 0
    return row
