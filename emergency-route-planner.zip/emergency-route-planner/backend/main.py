"""
main.py - the FastAPI web server (the backend's front door).

Run from the project folder:
    uvicorn backend.main:app --reload
Then open:
    http://127.0.0.1:8000        the app
    http://127.0.0.1:8000/docs   interactive API documentation (try every endpoint here)

The browser never computes routes itself. It sends what the user did to these
endpoints and redraws whatever GET /api/state returns, about 7 times a second.
"""
from pathlib import Path
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import database
from .simulation import Simulation

FRONTEND = Path(__file__).resolve().parent.parent / "frontend"

database.init_db()
sim = Simulation()

app = FastAPI(
    title="Emergency Route Planner API",
    description="Intelligent Emergency Vehicle Routing and Path Optimisation (Roll No 56-60)",
    version="1.0",
)
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")


# ---------- request bodies (FastAPI checks these automatically) ----------
class EmergencyRequest(BaseModel):
    x: Optional[float] = Field(None, description="Map x in metres; snapped to the nearest junction")
    y: Optional[float] = Field(None, description="Map y in metres")
    random_location: bool = False


class AccidentRequest(BaseModel):
    trip_id: Optional[int] = None


class SettingsRequest(BaseModel):
    hour: Optional[int] = Field(None, ge=0, le=23)
    weekend: Optional[bool] = None
    algorithm: Optional[Literal["astar", "dijkstra"]] = None
    corridor: Optional[bool] = None
    speed: Optional[int] = Field(None, ge=1, le=60)
    paused: Optional[bool] = None


# ---------- pages ----------
@app.get("/", include_in_schema=False)
def home():
    return FileResponse(FRONTEND / "index.html")


# ---------- read endpoints ----------
@app.get("/api/map", tags=["read"], summary="City layout: junctions, roads, hospitals (static)")
def get_map():
    return sim.city.to_dict()


@app.get("/api/state", tags=["read"], summary="Live state: ambulances, routes, traffic, log")
def get_state():
    with sim.lock:
        sim.tick()
        return sim.state()


@app.get("/api/history", tags=["read"], summary="Past emergency calls from the database")
def get_history(limit: int = 15):
    return {"summary": database.summary(), "incidents": database.recent_incidents(limit)}


# ---------- actions ----------
@app.post("/api/emergencies", tags=["actions"], summary="Report an emergency and dispatch an ambulance")
def report_emergency(req: EmergencyRequest):
    with sim.lock:
        sim.tick()
        trip = sim.report_emergency(req.x, req.y, req.random_location)
    if trip is None:
        raise HTTPException(409, "No free ambulance can reach this emergency right now.")
    return {"trip_id": trip.id, "ambulance": trip.ambulance.name, "hospital": trip.hospital["name"],
            "eta_s": round(trip.planned, 1)}


@app.post("/api/roads/{road_id}/toggle", tags=["actions"], summary="Block a road, or reopen it if blocked")
def toggle_road(road_id: int):
    with sim.lock:
        sim.tick()
        ok, message = sim.toggle_road(road_id)
    if not ok:
        raise HTTPException(409, message)
    return {"closed": road_id in sim.traffic.closed}


@app.post("/api/roads/accident", tags=["actions"], summary="Block a road ahead of a moving ambulance")
def accident(req: AccidentRequest):
    with sim.lock:
        sim.tick()
        trip, message = sim.accident_on_route(req.trip_id)
    if trip is None:
        raise HTTPException(409, message)
    return {"trip_id": trip.id}


@app.post("/api/roads/clear", tags=["actions"], summary="Reopen every blocked road")
def clear_roads():
    with sim.lock:
        sim.clear_closures()
    return {"ok": True}


@app.post("/api/settings", tags=["actions"], summary="Change time of day, day type, algorithm, corridor, speed")
def update_settings(req: SettingsRequest):
    with sim.lock:
        sim.tick()
        sim.update_settings(**req.model_dump())
        return sim.settings


@app.post("/api/reset", tags=["actions"], summary="Restart the simulation (history stays in the database)")
def reset():
    with sim.lock:
        sim.reset()
    return {"ok": True}
