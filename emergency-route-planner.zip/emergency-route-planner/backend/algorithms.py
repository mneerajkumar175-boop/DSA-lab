"""
algorithms.py - the route search algorithms.

  dijkstra()           explores outward from the start in order of travel time
  astar()              Dijkstra + a heuristic that pulls the search towards the goal
  shortest_distance()  Dijkstra on metres only (what you get if you ignore traffic)
  DStarLite            re-plans quickly when a road is closed or reopened mid-trip

All of them use a binary heap (heapq) as the priority queue.
"""
import heapq
import math
import time
from dataclasses import dataclass, field


@dataclass
class SearchResult:
    path: list
    nodes_expanded: int
    time_ms: float
    cost: float
    dist: list = field(default_factory=list)   # best cost to every junction


def _best_first(traffic, start, goal, use_heuristic=False, by_distance=False, corridor=None):
    """Shared code for Dijkstra and A*. A* = Dijkstra with a heuristic added to the priority."""
    city = traffic.city
    t0 = time.perf_counter()
    n = len(city.junctions)
    best = [math.inf] * n
    prev = [-1] * n
    done = [False] * n

    def h(v):
        return traffic.heuristic(v, goal) if use_heuristic else 0.0

    best[start] = 0.0
    queue = [(h(start), start)]
    expanded = 0
    while queue:
        _, u = heapq.heappop(queue)
        if done[u]:
            continue
        done[u] = True
        expanded += 1
        if u == goal:
            break
        for v, road_id in city.adjacency[u]:
            if road_id in traffic.closed:
                continue
            step = city.roads[road_id].length if by_distance else traffic.cost(u, v, road_id, corridor)
            new_cost = best[u] + step
            if new_cost < best[v]:
                best[v] = new_cost
                prev[v] = u
                heapq.heappush(queue, (new_cost + h(v), v))

    path = []
    if goal is not None and best[goal] < math.inf:
        v = goal
        while v != -1:
            path.append(v)
            v = prev[v]
        path.reverse()
    cost = best[goal] if goal is not None else 0.0
    return SearchResult(path, expanded, (time.perf_counter() - t0) * 1000, cost, best)


def dijkstra(traffic, start, goal=None, corridor=None):
    """With goal=None it finds travel times from start to every junction."""
    return _best_first(traffic, start, goal, corridor=corridor)


def astar(traffic, start, goal, corridor=None):
    return _best_first(traffic, start, goal, use_heuristic=True, corridor=corridor)


def shortest_distance(traffic, start, goal):
    return _best_first(traffic, start, goal, by_distance=True)


class DStarLite:
    """
    D* Lite (Koenig and Likhachev, 2002).

    It searches backwards from the goal and keeps two numbers for every junction:
        g[s]   - best known cost from s to the goal
        rhs[s] - one-step look-ahead: min over neighbours v of cost(s, v) + g[v]
    A junction is "inconsistent" when g != rhs; only those go in the priority queue.
    When a road changes we update just its two end junctions, and the search
    repairs only the part of the tree that changed, instead of starting again.
    km keeps the old queue keys valid while the ambulance (the start) moves.
    """

    def __init__(self, traffic, start, goal):
        self.traffic = traffic
        self.city = traffic.city
        n = len(self.city.junctions)
        self.start = self.last = start
        self.goal = goal
        self.km = 0.0
        self.g = [math.inf] * n
        self.rhs = [math.inf] * n
        self.queue = []          # heap of (k1, k2, junction)
        self.in_queue = {}       # junction -> its current valid key (older heap entries are ignored)
        self.rhs[goal] = 0.0
        self._push(goal, self._key(goal))

    def _key(self, s):
        m = min(self.g[s], self.rhs[s])
        return (m + self.traffic.heuristic(self.start, s) + self.km, m)

    def _push(self, s, key):
        self.in_queue[s] = key
        heapq.heappush(self.queue, (key[0], key[1], s))

    def _top(self):
        while self.queue:
            k1, k2, s = self.queue[0]
            if self.in_queue.get(s) == (k1, k2):
                return (k1, k2), s
            heapq.heappop(self.queue)       # outdated entry
        return None, None

    def update_vertex(self, u):
        if u != self.goal:
            self.rhs[u] = min((self.traffic.cost(u, v, rid) + self.g[v] for v, rid in self.city.adjacency[u]),
                              default=math.inf)
        self.in_queue.pop(u, None)
        if self.g[u] != self.rhs[u]:
            self._push(u, self._key(u))

    def compute_shortest_path(self):
        """Returns how many junctions were expanded."""
        expanded = 0
        while True:
            top_key, u = self._top()
            if u is None:
                break
            if not top_key < self._key(self.start) and self.rhs[self.start] == self.g[self.start]:
                break
            heapq.heappop(self.queue)
            del self.in_queue[u]
            expanded += 1
            new_key = self._key(u)
            if top_key < new_key:                  # key went up: put it back with the new key
                self._push(u, new_key)
            elif self.g[u] > self.rhs[u]:          # cost went down: accept it
                self.g[u] = self.rhs[u]
                for v, _ in self.city.adjacency[u]:
                    self.update_vertex(v)
            else:                                  # cost went up: reset and recheck
                self.g[u] = math.inf
                self.update_vertex(u)
                for v, _ in self.city.adjacency[u]:
                    self.update_vertex(v)
            if expanded > 100000:                  # safety stop
                break
        return expanded

    def move_start(self, new_start):
        self.km += self.traffic.heuristic(self.last, new_start)
        self.last = self.start = new_start

    def road_changed(self, road_id):
        road = self.city.roads[road_id]
        self.update_vertex(road.a)
        self.update_vertex(road.b)

    def path(self):
        """Follow the cheapest neighbour from the start to the goal."""
        if self.g[self.start] == math.inf:
            return []
        path = [self.start]
        u = self.start
        while u != self.goal and len(path) <= len(self.city.junctions):
            best_v, best_cost = None, math.inf
            for v, rid in self.city.adjacency[u]:
                c = self.traffic.cost(u, v, rid) + self.g[v]
                if c < best_cost:
                    best_v, best_cost = v, c
            if best_v is None or best_cost == math.inf:
                return []
            path.append(best_v)
            u = best_v
        return path if u == self.goal else []
