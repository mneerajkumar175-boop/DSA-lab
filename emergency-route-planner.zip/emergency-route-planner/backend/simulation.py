"""
simulation.py - ambulances, emergency calls and the live simulation clock.

Life of one emergency call (a "trip"):
  1. dispatch: one Dijkstra from the emergency gives the travel time to every
     junction, so we pick the nearest free ambulance and the fastest hospital
  2. leg 1: ambulance drives from where it is to the emergency
  3. it spends 90 s on scene treating the patient
  4. leg 2: emergency to the hospital
  5. the ambulance becomes available again at the hospital
Every trip has its own D* Lite planner. When a road is closed or reopened,
each moving ambulance re-plans from the next junction it will reach.

The clock moves forward each time the frontend asks for the state:
sim seconds = real seconds passed x speed (5x, 10x, 30x).
"""
import math
import random
import threading
import time

from . import database as db
from .algorithms import DStarLite, astar, dijkstra, shortest_distance
from .city import City
from .traffic import TrafficModel

ON_SCENE_SECONDS = 90
DRIVING = ("to_scene", "to_hospital")


def fmt(seconds):
    if seconds is None or not math.isfinite(seconds):
        return "--"
    s = max(0, round(seconds))
    return f"{s // 60}:{s % 60:02d}"


def num(value, digits=1):
    """JSON can't hold infinity, so send None instead."""
    return round(value, digits) if value is not None and math.isfinite(value) else None


def hour_label(hour, weekend):
    if weekend:
        return ("night" if hour < 6 or hour >= 22 else "quiet morning" if hour < 10
                else "weekend shopping traffic" if hour < 17 else "evening")
    return ("night, roads clear" if hour < 6 else "early morning" if hour < 8 else "morning rush" if hour < 12
            else "midday" if hour < 16 else "evening rush" if hour < 21 else "night")


class Ambulance:
    def __init__(self, name, node):
        self.name = name
        self.node = node              # last junction it passed
        self.state = "available"      # available / to_scene / on_scene / to_hospital
        self.trip = None


class Trip:
    def __init__(self, trip_id, ambulance, incident_node, hospital, started_at):
        self.id = trip_id
        self.ambulance = ambulance
        self.incident_node = incident_node
        self.hospital = hospital
        self.started_at = started_at
        self.leg = 1
        self.done = False
        self.finished_at = None
        self.total = None
        self.wait = 0.0               # seconds left on scene
        self.path = []                # junctions of the current route
        self.i = 0                    # index of the junction we last passed
        self.t = 0.0                  # seconds spent on the current road
        self.seg = 0.0                # seconds the current road takes
        self.trail = []               # junctions already driven
        self.baseline = []            # shortest-distance route, for comparison
        self.planner = None
        self.goal = None
        self.planned = 0.0
        self.no_route = False
        self.pre_change = None
        self.stats = {}


class Simulation:
    def __init__(self):
        self.lock = threading.Lock()  # one request at a time changes the simulation
        self.city = City()
        self.traffic = TrafficModel(self.city)
        self.settings = {"hour": 9, "weekend": False, "algorithm": "astar",
                         "corridor": True, "speed": 10, "paused": False}
        self.reset()

    # ------------------------------------------------------------------ setup
    def reset(self):
        self.ambulances = [Ambulance(f"A{k + 1}", node) for k, node in enumerate(self.city.bases)]
        self.trips = []
        self.sim_time = 0.0
        self.last_tick = time.monotonic()
        self.log_lines = []
        self.traffic.closed.clear()
        self.traffic.green_corridor = self.settings["corridor"]
        self.traffic.update(self.settings["hour"], self.settings["weekend"])
        self.log("Simulation started. Click the map to report an emergency.")

    def log(self, message):
        self.log_lines.insert(0, {"t": round(self.sim_time, 1), "message": message})
        del self.log_lines[40:]
        db.add_event(self.sim_time, message)

    # ------------------------------------------------------------------ clock
    def tick(self):
        now = time.monotonic()
        real_dt = min(1.0, now - self.last_tick)   # cap, so a sleeping laptop doesn't jump ahead
        self.last_tick = now
        if not self.settings["paused"]:
            self.step(real_dt * self.settings["speed"])

    def step(self, dt):
        self.sim_time += dt
        for trip in self.trips:
            if trip.done:
                continue
            amb = trip.ambulance
            if amb.state == "on_scene":
                trip.wait -= dt
                if trip.wait <= 0:
                    amb.state = "to_hospital"
                    trip.leg = 2
                    self._plan_leg(trip, trip.incident_node, trip.hospital["node"])
                    self.log(f"{amb.name} leaving scene for {trip.hospital['name']} (ETA {fmt(trip.planned)}).")
                continue
            left = dt
            while left > 0:
                if trip.i >= len(trip.path) - 1:
                    if not trip.no_route:
                        self._arrive(trip)
                    break
                if not math.isfinite(trip.seg):
                    break                          # stuck: road ahead closed and no other way
                need = trip.seg - trip.t
                if left < need:
                    trip.t += left
                    left = 0
                else:                              # reached the next junction
                    left -= need
                    trip.i += 1
                    trip.t = 0.0
                    amb.node = trip.path[trip.i]
                    trip.trail.append(amb.node)
                    trip.seg = self._segment_time(trip)
        # forget finished trips after 10 sim minutes
        self.trips = [t for t in self.trips if not t.done or self.sim_time - t.finished_at < 600]

    # ------------------------------------------------------------------ routing helpers
    def _segment_time(self, trip):
        if trip.i >= len(trip.path) - 1:
            return 0.0
        u, v = trip.path[trip.i], trip.path[trip.i + 1]
        return self.traffic.cost(u, v, self.city.road_between(u, v))

    def remaining(self, trip):
        total = max(0.0, trip.seg - trip.t)
        for u, v in zip(trip.path[trip.i + 1:], trip.path[trip.i + 2:]):
            total += self.traffic.cost(u, v, self.city.road_between(u, v))
        return total

    def _plan_leg(self, trip, start, goal):
        tr = self.traffic
        d = dijkstra(tr, start, goal)
        a = astar(tr, start, goal)
        base = shortest_distance(tr, start, goal)
        chosen = a if self.settings["algorithm"] == "astar" else d

        t0 = time.perf_counter()
        trip.planner = DStarLite(tr, start, goal)
        d_expanded = trip.planner.compute_shortest_path()
        d_ms = (time.perf_counter() - t0) * 1000

        trip.goal = goal
        trip.path = chosen.path or [start]
        trip.no_route = not chosen.path
        trip.i, trip.t = 0, 0.0
        trip.seg = self._segment_time(trip)
        trip.trail = [start]
        trip.baseline = base.path
        trip.planned = tr.path_time(trip.path)
        trip.stats = {
            "dijkstra": {"expanded": d.nodes_expanded, "ms": d.time_ms, "route_s": tr.path_time(d.path)},
            "astar": {"expanded": a.nodes_expanded, "ms": a.time_ms, "route_s": tr.path_time(a.path)},
            "dstar_first": {"expanded": d_expanded, "ms": d_ms},
            "replan": None,
            "baseline_s": tr.path_time(base.path, corridor=False),
            "smart_s": tr.path_time(astar(tr, start, goal, corridor=False).path, corridor=False),
            "smart_corridor_s": tr.path_time(astar(tr, start, goal, corridor=True).path, corridor=True),
            "distance_km": tr.path_length(trip.path) / 1000,
        }

    def _replan(self, trip, changed_road=None):
        """changed_road=None means everything changed (new hour, corridor toggle): start a fresh D* Lite."""
        amb = trip.ambulance
        old_remaining = trip.pre_change
        trip.pre_change = None
        if trip.done or amb.state not in DRIVING or trip.i >= len(trip.path) - 1:
            return
        current, nxt = trip.path[trip.i], trip.path[trip.i + 1]
        before = trip.path[trip.i + 1:]
        if old_remaining is None:
            old_remaining = self.remaining(trip)

        t0 = time.perf_counter()
        if changed_road is None:
            trip.planner = DStarLite(self.traffic, nxt, trip.goal)
        else:
            trip.planner.move_start(nxt)
            trip.planner.road_changed(changed_road)
        expanded = trip.planner.compute_shortest_path()
        ms = (time.perf_counter() - t0) * 1000

        new_path = trip.planner.path()
        if not new_path:
            trip.path, trip.i, trip.no_route = [current, nxt], 0, True
            self.log(f"{amb.name}: no open road to the destination.")
            return
        trip.no_route = False
        trip.path, trip.i = [current] + new_path, 0
        if changed_road is not None and new_path != before:
            scratch = astar(self.traffic, nxt, trip.goal)
            trip.stats["replan"] = {"dstar_expanded": expanded, "dstar_ms": ms,
                                    "astar_expanded": scratch.nodes_expanded, "astar_ms": scratch.time_ms,
                                    "route_s": self.remaining(trip)}
            diff = self.remaining(trip) - old_remaining
            self.log(f"{amb.name} re-routed ({'+' if diff >= 0 else '-'}{fmt(abs(diff))}). "
                     f"D* Lite expanded {expanded} junctions, A* from scratch {scratch.nodes_expanded}.")

    def _replan_all(self, changed_road=None):
        for trip in self.trips:
            self._replan(trip, changed_road)

    def _arrive(self, trip):
        amb = trip.ambulance
        if trip.leg == 1:
            amb.state = "on_scene"
            trip.wait = ON_SCENE_SECONDS
            db.update_incident(trip.id, status="on_scene", time_to_scene_s=self.sim_time - trip.started_at)
            self.log(f"{amb.name} reached emergency #{trip.id}.")
        else:
            amb.state = "available"
            amb.trip = None
            trip.done = True
            trip.finished_at = self.sim_time
            trip.total = self.sim_time - trip.started_at
            db.update_incident(trip.id, status="completed", total_time_s=trip.total)
            self.log(f"{amb.name} delivered patient #{trip.id} to {trip.hospital['name']}. Total {fmt(trip.total)}.")

    # ------------------------------------------------------------------ actions from the API
    def report_emergency(self, x=None, y=None, random_location=False):
        if random_location or x is None or y is None:
            node = random.randrange(len(self.city.junctions))
        else:
            node = self.city.nearest_junction(x, y)
        far = dijkstra(self.traffic, node).dist
        free = [a for a in self.ambulances if a.state == "available" and far[a.node] < math.inf]
        if not free:
            self.log("New emergency, but no free ambulance can reach it right now.")
            return None
        amb = min(free, key=lambda a: far[a.node])
        hospitals = [h for h in self.city.hospitals if far[h["node"]] < math.inf] or self.city.hospitals
        hospital = min(hospitals, key=lambda h: far[h["node"]])

        trip_id = db.add_incident(node, amb.name, hospital["name"], self.settings["hour"], self.settings["algorithm"])
        trip = Trip(trip_id, amb, node, hospital, self.sim_time)
        amb.state, amb.trip = "to_scene", trip
        self.trips.append(trip)
        self._plan_leg(trip, amb.node, node)
        db.update_incident(trip_id, eta_scene_s=num(trip.planned))
        self.log(f"Emergency #{trip_id}: {amb.name} dispatched (ETA {fmt(trip.planned)}), "
                 f"patient will go to {hospital['name']}.")
        return trip

    def toggle_road(self, road_id):
        if road_id < 0 or road_id >= len(self.city.roads) or self.city.roads[road_id].removed:
            return False, "No such road."
        if road_id in self.traffic.closed:
            self.traffic.closed.discard(road_id)
            self.log("Road reopened.")
        else:
            for trip in self.trips:
                if trip.ambulance.state in DRIVING and trip.i < len(trip.path) - 1 and \
                        self.city.road_between(trip.path[trip.i], trip.path[trip.i + 1]) == road_id:
                    msg = f"{trip.ambulance.name} is already on that road, so it can't be closed now."
                    self.log(msg)
                    return False, msg
            for trip in self.trips:
                if not trip.done:
                    trip.pre_change = self.remaining(trip)
            self.traffic.closed.add(road_id)
            self.log("Road blocked.")
        self._replan_all(road_id)
        return True, "ok"

    def accident_on_route(self, trip_id=None):
        driving = [t for t in self.trips if t.ambulance.state in DRIVING and not t.done]
        trip = next((t for t in driving if t.id == trip_id), None)
        if trip is None or len(trip.path) - trip.i < 4:      # pick the ambulance with the most route left
            trip = max(driving, key=lambda t: len(t.path) - t.i, default=None)
        if trip is None or len(trip.path) - trip.i < 4:
            msg = "No ambulance has enough route left for an accident."
            self.log(msg)
            return None, msg
        k = trip.i + 1 + (len(trip.path) - trip.i - 2) // 2
        road_id = self.city.road_between(trip.path[k], trip.path[k + 1])
        self.log(f"Accident reported ahead of {trip.ambulance.name}.")
        self.toggle_road(road_id)
        return trip, "ok"

    def clear_closures(self):
        if self.traffic.closed:
            self.traffic.closed.clear()
            self._replan_all(None)
            self.log("All blocked roads reopened; routes re-planned.")

    def update_settings(self, **changes):
        changes = {k: v for k, v in changes.items() if v is not None}
        traffic_changed = any(k in changes and changes[k] != self.settings[k] for k in ("hour", "weekend"))
        corridor_changed = "corridor" in changes and changes["corridor"] != self.settings["corridor"]
        self.settings.update(changes)
        if traffic_changed:
            self.traffic.update(self.settings["hour"], self.settings["weekend"])
            self._replan_all(None)
            self.log(f"Traffic set to {self.settings['hour']:02d}:00 "
                     f"{'weekend' if self.settings['weekend'] else 'weekday'}; routes re-planned.")
        if corridor_changed:
            self.traffic.green_corridor = self.settings["corridor"]
            self._replan_all(None)
            self.log(f"Green corridor {'on' if self.settings['corridor'] else 'off'}.")
        if "algorithm" in changes:
            name = "A*" if self.settings["algorithm"] == "astar" else "Dijkstra"
            self.log(f"New calls will be routed with {name}.")

    # ------------------------------------------------------------------ state for the frontend
    def _xy(self, node):
        j = self.city.junctions[node]
        return [round(j.x, 1), round(j.y, 1)]

    def vehicle_position(self, trip):
        if trip.i >= len(trip.path) - 1:
            return self._xy(trip.path[-1])
        a = self.city.junctions[trip.path[trip.i]]
        b = self.city.junctions[trip.path[trip.i + 1]]
        f = min(1.0, trip.t / trip.seg) if math.isfinite(trip.seg) and trip.seg > 0 else 0.0
        return [round(a.x + (b.x - a.x) * f, 1), round(a.y + (b.y - a.y) * f, 1)]

    def _trip_view(self, trip):
        amb = trip.ambulance
        driving = amb.state in DRIVING and not trip.done
        if trip.done:
            phase, eta, label = "Patient delivered", trip.total, "total response time"
        elif amb.state == "to_scene":
            phase, eta, label = "Heading to scene", self.remaining(trip), "to scene"
        elif amb.state == "on_scene":
            phase, eta, label = "Treating patient on scene", trip.wait, "until leaving for hospital"
        else:
            phase, eta, label = "Taking patient to hospital", self.remaining(trip), "to " + trip.hospital["name"]
        leg_done = 1 - self.remaining(trip) / max(1.0, trip.planned)
        progress = 1.0 if trip.done else 0.5 if amb.state == "on_scene" else (trip.leg - 1 + leg_done) / 2
        pos = self.vehicle_position(trip) if driving else None
        st = trip.stats
        replan = st.get("replan")
        return {
            "id": trip.id, "ambulance": amb.name, "leg": trip.leg, "phase": phase,
            "eta_s": num(eta), "eta_label": label, "progress": max(0.0, min(1.0, progress)),
            "hospital": trip.hospital["name"], "distance_km": round(st.get("distance_km", 0), 2),
            "no_route": trip.no_route, "done": trip.done,
            "incident": self._xy(trip.incident_node) if trip.leg == 1 and not trip.done else None,
            "route": [pos] + [self._xy(n) for n in trip.path[trip.i + 1:]] if driving else [],
            "trail": [self._xy(n) for n in trip.trail] + ([pos] if pos else []) if driving else [],
            "baseline": [self._xy(n) for n in trip.baseline] if driving else [],
            "compare": {"baseline_s": num(st["baseline_s"]), "smart_s": num(st["smart_s"]),
                        "smart_corridor_s": num(st["smart_corridor_s"])},
            "algorithms": {
                "dijkstra": {k: num(v, 2) for k, v in st["dijkstra"].items()},
                "astar": {k: num(v, 2) for k, v in st["astar"].items()},
                "dstar_first": {k: num(v, 2) for k, v in st["dstar_first"].items()},
                "replan": {k: num(v, 2) for k, v in replan.items()} if replan else None,
            },
        }

    def state(self):
        green = set()
        if self.settings["corridor"]:
            for trip in self.trips:
                if trip.ambulance.state in DRIVING and not trip.done:
                    green.update(n for n in trip.path[trip.i + 1:trip.i + 4] if self.city.junctions[n].has_signal)
        ambulances = []
        for amb in self.ambulances:
            trip = amb.trip
            if amb.state in DRIVING:
                pos = self.vehicle_position(trip)
            else:
                pos = self._xy(amb.node)
            status = {"available": "Available",
                      "to_scene": f"To emergency #{trip.id if trip else ''}, {fmt(self.remaining(trip)) if trip else ''}",
                      "on_scene": f"On scene #{trip.id if trip else ''}",
                      "to_hospital": f"To {trip.hospital['name'] if trip else ''}, "
                                     f"{fmt(self.remaining(trip)) if trip else ''}"}[amb.state]
            ambulances.append({"name": amb.name, "state": amb.state, "busy": amb.state != "available",
                               "x": pos[0], "y": pos[1], "status": status, "trip_id": trip.id if trip else None})
        return {
            "sim_time": round(self.sim_time, 1),
            "settings": self.settings,
            "hour_label": hour_label(self.settings["hour"], self.settings["weekend"]),
            "traffic": [self.traffic.level(r.id) for r in self.city.roads],   # 0 clear, 1 slow, 2 jammed
            "closed": sorted(self.traffic.closed),
            "green_signals": sorted(green),
            "ambulances": ambulances,
            "trips": [self._trip_view(t) for t in self.trips],
            "log": self.log_lines,
        }
