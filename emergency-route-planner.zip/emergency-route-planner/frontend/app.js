// app.js - the frontend.
// It does NO routing itself: it asks the backend for the state, draws it,
// and sends the user's clicks to the API.
{
const $ = s => document.querySelector(s);
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

let map = null;          // static city layout from GET /api/map
let state = null;        // live state from GET /api/state
let selectedId = null;   // trip shown in the side panel
let mode = 'dispatch';   // 'dispatch' or 'block'
let hoverRoad = -1;
let settingsSynced = false;

// ---------- talking to the backend ----------
async function api(path, body) {
  const opts = body === undefined ? {} :
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || `${path} failed (${res.status})`);
  return data;
}
const act = (path, body) => api(path, body).catch(e => console.warn(e.message));

async function poll() {
  try {
    state = await api('/api/state');
    $('#offline').hidden = true;
    if (!settingsSynced) { syncControls(state.settings); settingsSynced = true; }
    renderPanel();
  } catch (e) {
    $('#offline').hidden = false;
  }
  setTimeout(poll, 150);
}

async function loadHistory() {
  try {
    const h = await api('/api/history?limit=12');
    const s = h.summary;
    $('#histSum').textContent = s.calls
      ? `${s.calls} calls saved, ${s.completed} completed` + (s.avg_to_scene != null ? ` · average ${fmt(s.avg_to_scene)} to scene` : '') + (s.avg_total != null ? `, ${fmt(s.avg_total)} total` : '')
      : 'No calls saved yet.';
    $('#hist').innerHTML = h.incidents.map(r =>
      `<tr><td>${esc(r.id)}</td><td>${esc(r.ambulance)}</td><td>${esc(r.hospital)}</td>` +
      `<td class="n">${fmt(r.time_to_scene_s)}</td><td class="n">${r.status === 'completed' ? fmt(r.total_time_s) : esc(r.status.replace('_', ' '))}</td></tr>`
    ).join('');
  } catch (e) { /* offline banner already shows */ }
  setTimeout(loadHistory, 3000);
}

// ---------- helpers ----------
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = s => {
  if (s == null || !isFinite(s)) return '—';
  s = Math.max(0, Math.round(s));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
};
const fmtT = s => {
  s = Math.floor(s);
  const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60;
  return (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
};

// ---------- drawing the map ----------
const cv = $('#map'), cx = cv.getContext('2d');
let W = 0, H = 0, dpr = 1, S = 1, OX = 0, OY = 0;
const C = {};
const probe = document.createElement('span');
probe.style.display = 'none';
document.body.append(probe);
function refreshColors() {
  for (const k of ['map', 'casing', 'road', 'river', 'slow', 'jam', 'red', 'hosp', 'go', 'ink', 'muted']) {
    probe.style.color = `var(--${k})`;
    C[k] = getComputedStyle(probe).color;
  }
}
function fit() {
  const r = cv.getBoundingClientRect();
  W = r.width; H = r.height; dpr = devicePixelRatio || 1;
  cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  if (!map) return;
  const [x0, y0, x1, y1] = map.bounds;
  const top = W < 520 ? 104 : 64, bot = W < 520 ? 84 : 52, side = 16;
  S = Math.min((W - 2 * side) / (x1 - x0 + 120), (H - top - bot) / (y1 - y0 + 120));
  OX = (W - (x1 - x0) * S) / 2 - x0 * S;
  OY = top + (H - top - bot - (y1 - y0) * S) / 2 - y0 * S;
}
const X = x => OX + x * S, Y = y => OY + y * S;
function line(pts, w, col, dash) {
  if (pts.length < 2) return;
  cx.beginPath();
  pts.forEach(([x, y], i) => i ? cx.lineTo(X(x), Y(y)) : cx.moveTo(X(x), Y(y)));
  cx.lineWidth = w; cx.strokeStyle = col; cx.setLineDash(dash || []); cx.stroke(); cx.setLineDash([]);
}
function label(txt, x, y, font, col) {
  cx.font = font; cx.textAlign = 'center'; cx.lineWidth = 4; cx.strokeStyle = C.map;
  cx.strokeText(txt, x, y); cx.fillStyle = col; cx.fillText(txt, x, y);
}
const roadPts = r => [[map.junctions[r.a].x, map.junctions[r.a].y], [map.junctions[r.b].x, map.junctions[r.b].y]];
const roadWidth = r => r.kind === 'local' ? [Math.max(3, 26 * S), Math.max(1.6, 15 * S)] : [Math.max(4.5, 38 * S), Math.max(2.6, 24 * S)];

function draw(now) {
  cx.setTransform(dpr, 0, 0, dpr, 0, 0);
  cx.fillStyle = C.map; cx.fillRect(0, 0, W, H);
  if (!map || !state) { requestAnimationFrame(draw); return; }
  cx.lineCap = 'round'; cx.lineJoin = 'round';
  const [x0, , x1] = map.bounds;

  // river
  cx.beginPath();
  for (let x = x0 - 600; x <= x1 + 600; x += 40) {
    const y = map.river_y + 45 * Math.sin(x / 520);
    x === x0 - 600 ? cx.moveTo(X(x), Y(y)) : cx.lineTo(X(x), Y(y));
  }
  cx.lineCap = 'butt'; cx.lineWidth = 150 * S; cx.strokeStyle = C.river; cx.stroke(); cx.lineCap = 'round';

  // roads coloured by the traffic level the backend sent (0 clear, 1 slow, 2 jammed)
  for (const r of map.roads) line(roadPts(r), roadWidth(r)[0], C.casing);
  const colour = [C.road, C.slow, C.jam];
  for (const r of map.roads) line(roadPts(r), roadWidth(r)[1], colour[state.traffic[r.id]]);

  // blocked roads and hover
  const roadById = id => map.roads.find(r => r.id === id);
  for (const id of state.closed) { const r = roadById(id); if (r) line(roadPts(r), roadWidth(r)[1] + 1, C.red, [4, 4]); }
  if (mode === 'block' && hoverRoad >= 0) {
    const r = roadById(hoverRoad);
    cx.globalAlpha = .5; line(roadPts(r), roadWidth(r)[0] + 6, C.red); cx.globalAlpha = 1;
  }

  // routes
  const sel = selectedTrip();
  if (sel && sel.baseline.length) line(sel.baseline, 2.5, C.muted, [6, 6]);
  for (const t of state.trips) {
    if (!t.route.length) continue;
    const w = t === sel ? 5 : 3.5;
    cx.globalAlpha = t === sel ? 1 : .6;
    line(t.route, w + 4, C.map); line(t.route, w, C.ink);
    cx.globalAlpha = .45; line(t.trail, 3, C.red); cx.globalAlpha = 1;
  }

  // traffic signals (green = switched for an ambulance)
  const green = new Set(state.green_signals);
  for (const j of map.junctions) {
    if (!j.signal) continue;
    cx.beginPath();
    if (green.has(j.id)) {
      cx.arc(X(j.x), Y(j.y), 5, 0, 7); cx.fillStyle = C.go; cx.fill();
      cx.lineWidth = 2; cx.strokeStyle = C.map; cx.stroke();
    } else {
      cx.arc(X(j.x), Y(j.y), 2.2, 0, 7); cx.fillStyle = C.muted; cx.fill();
    }
  }

  // blocked markers
  for (const id of state.closed) {
    const r = roadById(id); if (!r) continue;
    const [[ax, ay], [bx, by]] = roadPts(r), x = X((ax + bx) / 2), y = Y((ay + by) / 2);
    cx.beginPath(); cx.arc(x, y, 8, 0, 7); cx.fillStyle = C.ink; cx.fill();
    cx.beginPath(); cx.moveTo(x - 3.5, y - 3.5); cx.lineTo(x + 3.5, y + 3.5); cx.moveTo(x + 3.5, y - 3.5); cx.lineTo(x - 3.5, y + 3.5);
    cx.lineWidth = 2; cx.strokeStyle = C.map; cx.stroke();
  }

  // hospitals
  for (const h of map.hospitals) {
    const x = X(h.x), y = Y(h.y);
    cx.beginPath(); cx.roundRect(x - 10, y - 10, 20, 20, 4); cx.fillStyle = C.hosp; cx.fill();
    cx.lineWidth = 2; cx.strokeStyle = C.map; cx.stroke();
    cx.fillStyle = '#fff'; cx.font = '700 13px Inter,sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
    cx.fillText('H', x, y + .5); cx.textBaseline = 'alphabetic';
    if (W >= 520) label(h.name, x, y + 24, '600 12px Inter,sans-serif', C.ink);
  }

  // emergencies
  for (const t of state.trips) {
    if (!t.incident) continue;
    const x = X(t.incident[0]), y = Y(t.incident[1]);
    cx.beginPath(); cx.arc(x, y - 14, 9, 0, 7); cx.moveTo(x - 5, y - 8); cx.lineTo(x, y); cx.lineTo(x + 5, y - 8);
    cx.fillStyle = C.ink; cx.fill();
    cx.fillStyle = C.map; cx.font = '700 12px Inter,sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle';
    cx.fillText('!', x, y - 13.5); cx.textBaseline = 'alphabetic';
    label('#' + t.id, x, y - 28, '600 12px Inter,sans-serif', C.ink);
  }

  // ambulances
  const ph = reduce ? 0 : (now / 900) % 1;
  for (const a of state.ambulances) {
    const x = X(a.x), y = Y(a.y), r = a.busy ? 9 : 7;
    if (a.busy && !reduce) {
      cx.beginPath(); cx.arc(x, y, r + 3 + 10 * ph, 0, 7); cx.strokeStyle = C.red;
      cx.globalAlpha = 1 - ph; cx.lineWidth = 2; cx.stroke(); cx.globalAlpha = 1;
    }
    cx.beginPath(); cx.arc(x, y, r, 0, 7); cx.fillStyle = C.red; cx.fill();
    cx.lineWidth = 2; cx.strokeStyle = C.map; cx.stroke();
    cx.fillStyle = '#fff';
    const p = r * .55, q = r * .18;
    cx.fillRect(x - p, y - q, 2 * p, 2 * q); cx.fillRect(x - q, y - p, 2 * q, 2 * p);
    label(a.name, x, y - r - 6, '700 12px Inter,sans-serif', a.busy ? C.red : C.muted);
  }
  requestAnimationFrame(draw);
}

// ---------- side panel ----------
function selectedTrip() {
  if (!state || !state.trips.length) return null;
  let t = state.trips.find(t => t.id === selectedId);
  if (!t) { t = state.trips.filter(t => !t.done).pop() || state.trips[state.trips.length - 1]; selectedId = t.id; }
  return t;
}
function setBar(id, v, max, win) {
  const b = $(id);
  b.querySelector('b').textContent = fmt(v);
  b.querySelector('i').style.width = (v != null && max > 0 ? Math.max(2, 100 * v / max) : 0) + '%';
  b.classList.toggle('win', win);
}
let lastLogKey = '';
function renderPanel() {
  const st = state.settings;
  $('#clock').textContent = `T+${fmtT(state.sim_time)} · ${st.speed}× speed`;
  $('#hourOut').textContent = `${String(st.hour).padStart(2, '0')}:00 · ${state.hour_label}`;
  $('#pause').textContent = st.paused ? 'Resume' : 'Pause';

  const t = selectedTrip();
  $('#empty').hidden = !!t; $('#tripCard').hidden = !t; $('#why').hidden = !t; $('#algs').hidden = !t;
  if (t) {
    $('#tUnit').textContent = t.ambulance;
    $('#tPhase').textContent = t.phase;
    $('#tEta').textContent = fmt(t.eta_s);
    $('#tEtaLbl').textContent = t.eta_label;
    $('#tRoute').textContent = `Emergency #${t.id} → ${t.hospital} · this leg ${t.distance_km.toFixed(1)} km`;
    $('#tWarn').hidden = !t.no_route;
    $('#tProg').style.width = (t.progress * 100) + '%';

    const c = t.compare, max = Math.max(c.baseline_s || 0, c.smart_s || 0, c.smart_corridor_s || 0);
    const used = st.corridor ? c.smart_corridor_s : c.smart_s;
    $('#whyH').textContent = `Why this route (leg ${t.leg} of 2: ${t.leg === 1 ? 'to scene' : 'to hospital'})`;
    setBar('#b0', c.baseline_s, max, false);
    setBar('#b1', c.smart_s, max, !st.corridor);
    setBar('#b2', c.smart_corridor_s, max, st.corridor);
    $('#saved').textContent = used != null && c.baseline_s
      ? `Planned route is ${Math.round(100 * (c.baseline_s - used) / c.baseline_s)}% faster than the shortest-distance route.` : '';

    const A = t.algorithms;
    const row = (name, e, ms, route) => `<tr><td>${name}</td><td class="n">${e}</td><td class="n">${Number(ms).toFixed(2)} ms</td><td class="n">${route}</td></tr>`;
    let html = row('Dijkstra', A.dijkstra.expanded, A.dijkstra.ms, fmt(A.dijkstra.route_s)) +
               row('A*', A.astar.expanded, A.astar.ms, fmt(A.astar.route_s)) +
               row('D* Lite, first plan', A.dstar_first.expanded, A.dstar_first.ms, 'same');
    if (A.replan) {
      html += row('D* Lite, re-plan', A.replan.dstar_expanded, A.replan.dstar_ms, fmt(A.replan.route_s)).replace('<tr>', '<tr class="sep">') +
              row('A* from scratch', A.replan.astar_expanded, A.replan.astar_ms, fmt(A.replan.route_s));
    } else {
      html += '<tr class="sep"><td colspan="4" style="color:var(--muted)">Block a road on the route to see D* Lite re-plan.</td></tr>';
    }
    $('#algT').innerHTML = html;
  }

  // fleet: build the buttons once, then only update their text (so clicks aren't lost)
  const fleet = $('#fleet');
  if (fleet.children.length !== state.ambulances.length) {
    fleet.innerHTML = state.ambulances.map((a, k) => `<li><button data-k="${k}"><i></i><b>${esc(a.name)}</b><span></span></button></li>`).join('');
  }
  state.ambulances.forEach((a, k) => {
    const b = fleet.children[k].firstChild;
    b.querySelector('span').textContent = a.status;
    b.querySelector('i').className = a.busy ? 'busy' : '';
    b.classList.toggle('on', !!t && !t.done && a.trip_id === t.id);
  });

  // log: only redraw when it changed
  const key = state.log.length + '|' + (state.log[0] ? state.log[0].t + state.log[0].message : '');
  if (key !== lastLogKey) {
    lastLogKey = key;
    const L = $('#log');
    L.replaceChildren(...state.log.map(e => {
      const li = document.createElement('li'), tm = document.createElement('time');
      tm.textContent = 'T+' + fmtT(e.t);
      li.append(tm, e.message);
      return li;
    }));
  }
}

// ---------- controls ----------
function press(group, value) {
  $(group).querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', b.dataset.v === String(value)));
}
function syncControls(s) {
  $('#hour').value = s.hour;
  press('#day', s.weekend ? 'we' : 'wk');
  press('#algo', s.algorithm);
  press('#spd', s.speed);
  $('#corr').checked = s.corridor;
}
function segment(group, fn) {
  $(group).addEventListener('click', ev => {
    const b = ev.target.closest('button'); if (!b) return;
    press(group, b.dataset.v); fn(b.dataset.v);
  });
}
segment('#mode', v => {
  mode = v; hoverRoad = -1; cv.classList.toggle('block', v === 'block');
  $('#hint').textContent = v === 'dispatch' ? 'Click anywhere to report an emergency' : 'Click a road to block it, click again to reopen';
});
segment('#day', v => act('/api/settings', { weekend: v === 'we' }));
segment('#algo', v => act('/api/settings', { algorithm: v }));
segment('#spd', v => act('/api/settings', { speed: +v }));
$('#hour').addEventListener('change', e => act('/api/settings', { hour: +e.target.value }));
$('#hour').addEventListener('input', e => { $('#hourOut').textContent = `${String(e.target.value).padStart(2, '0')}:00`; });
$('#corr').addEventListener('change', e => act('/api/settings', { corridor: e.target.checked }));
$('#pause').addEventListener('click', () => act('/api/settings', { paused: !state.settings.paused }));
$('#rand').addEventListener('click', async () => {
  const r = await api('/api/emergencies', { random_location: true }).catch(e => console.warn(e.message));
  if (r) selectedId = r.trip_id;
});
$('#acc').addEventListener('click', () => act('/api/roads/accident', { trip_id: selectedId }));
$('#clr').addEventListener('click', () => act('/api/roads/clear', {}));
$('#reset').addEventListener('click', () => { selectedId = null; act('/api/reset', {}); });
$('#fleet').addEventListener('click', ev => {
  const b = ev.target.closest('button'); if (!b || !state) return;
  const a = state.ambulances[+b.dataset.k];
  if (a.trip_id != null) { selectedId = a.trip_id; renderPanel(); }
});

// map clicks: x/y are converted from screen pixels to city metres
const toWorld = ev => { const r = cv.getBoundingClientRect(); return [(ev.clientX - r.left - OX) / S, (ev.clientY - r.top - OY) / S]; };
function nearestRoad(x, y) {
  let best = -1, bd = Infinity;
  for (const r of map.roads) {
    const [[ax, ay], [bx, by]] = roadPts(r), dx = bx - ax, dy = by - ay;
    const t = Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy)));
    const d = Math.hypot(ax + t * dx - x, ay + t * dy - y);
    if (d < bd) { bd = d; best = r.id; }
  }
  return bd < Math.max(40, 22 / S) ? best : -1;
}
cv.addEventListener('click', async ev => {
  if (!map) return;
  const [x, y] = toWorld(ev);
  if (mode === 'dispatch') {
    const r = await api('/api/emergencies', { x, y }).catch(e => console.warn(e.message));
    if (r) selectedId = r.trip_id;
  } else {
    const id = nearestRoad(x, y);
    if (id >= 0) act(`/api/roads/${id}/toggle`, {});
  }
});
cv.addEventListener('mousemove', ev => { if (mode === 'block' && map) { const [x, y] = toWorld(ev); hoverRoad = nearestRoad(x, y); } });
cv.addEventListener('mouseleave', () => { hoverRoad = -1; });

// ---------- start ----------
refreshColors();
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshColors);
const ro = new ResizeObserver(fit);
ro.observe(cv);
(async function start() {
  try {
    map = await api('/api/map');
  } catch (e) {
    $('#offline').hidden = false;
    setTimeout(start, 1500);
    return;
  }
  fit();
  poll();
  loadHistory();
  requestAnimationFrame(draw);
})();
}
