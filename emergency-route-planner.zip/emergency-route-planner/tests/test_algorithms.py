"""
Tests that the three algorithms agree.
Run from the project folder:   python -m pytest -q
"""
import math
import random

from backend.algorithms import DStarLite, astar, dijkstra
from backend.city import City
from backend.traffic import TrafficModel


def make_traffic(hour=9):
    traffic = TrafficModel(City())
    traffic.update(hour, False)
    return traffic


def test_city_is_connected():
    traffic = make_traffic()
    dist = dijkstra(traffic, 0).dist
    assert all(d < math.inf for d in dist)


def test_astar_matches_dijkstra_and_explores_less():
    traffic = make_traffic(18)
    rng = random.Random(1)
    n = len(traffic.city.junctions)
    fewer = 0
    for _ in range(100):
        a, b = rng.randrange(n), rng.randrange(n)
        d, s = dijkstra(traffic, a, b), astar(traffic, a, b)
        assert math.isclose(d.cost, s.cost, rel_tol=1e-9)
        assert s.nodes_expanded <= d.nodes_expanded
        fewer += s.nodes_expanded < d.nodes_expanded
    assert fewer > 50


def test_dstar_lite_replans_correctly_after_closures():
    traffic = make_traffic(9)
    rng = random.Random(7)
    n = len(traffic.city.junctions)
    for _ in range(40):
        traffic.closed.clear()
        start, goal = rng.randrange(n), rng.randrange(n)
        planner = DStarLite(traffic, start, goal)
        planner.compute_shortest_path()
        for _ in range(4):
            path = planner.path()
            if len(path) < 3:
                break
            k = rng.randrange(len(path) - 1)
            road = traffic.city.road_between(path[k], path[k + 1])
            planner.move_start(path[1])                    # ambulance moved one junction
            traffic.closed.add(road)                       # then a road on its route closed
            planner.road_changed(road)
            planner.compute_shortest_path()
            expected = dijkstra(traffic, path[1], goal).cost
            assert math.isclose(traffic.path_time(planner.path()), expected, rel_tol=1e-9)


def test_green_corridor_is_never_slower():
    traffic = make_traffic(18)
    for a, b in [(0, 215), (17, 198), (40, 170)]:
        normal = traffic.path_time(astar(traffic, a, b, corridor=False).path, corridor=False)
        corridor = traffic.path_time(astar(traffic, a, b, corridor=True).path, corridor=True)
        assert corridor <= normal
