"""
Tests the REST API end to end (uses a temporary database).
Run from the project folder:   python -m pytest -q
"""
import os
import tempfile

os.environ["DISPATCH_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from backend.main import app, sim  # noqa: E402

client = TestClient(app)


def test_map_and_state():
    m = client.get("/api/map").json()
    assert len(m["junctions"]) == 216 and len(m["hospitals"]) == 4
    s = client.get("/api/state").json()
    assert len(s["ambulances"]) == 5 and len(s["traffic"]) >= len(m["roads"])


def test_full_emergency_is_saved_in_database():
    client.post("/api/reset")
    r = client.post("/api/emergencies", json={"x": 3000, "y": 2800})
    assert r.status_code == 200
    trip_id = r.json()["trip_id"]
    for _ in range(200):                      # run 2000 simulated seconds
        sim.step(10)
    history = client.get("/api/history").json()
    row = next(i for i in history["incidents"] if i["id"] == trip_id)
    assert row["status"] == "completed" and row["total_time_s"] > 0


def test_blocking_a_road_reroutes():
    client.post("/api/reset")
    trip_id = client.post("/api/emergencies", json={"x": 4300, "y": 3000}).json()["trip_id"]
    r = client.post("/api/roads/accident", json={"trip_id": trip_id})
    if r.status_code == 200:
        trip = next(t for t in client.get("/api/state").json()["trips"] if t["id"] == trip_id)
        assert trip["algorithms"]["replan"] is not None
    client.post("/api/roads/clear")
    assert client.get("/api/state").json()["closed"] == []


def test_bad_settings_are_rejected():
    assert client.post("/api/settings", json={"hour": 30}).status_code == 422
    assert client.post("/api/settings", json={"algorithm": "bfs"}).status_code == 422
